#pragma once

#include "agmRKF45Vect.h"

typedef uint32_t (*RKF45_FUNCTION_VECTOR)(void *, const double, const CagmRKF45Vect&, CagmRKF45Vect&);
typedef uint32_t (*RKF45_FUNCTION_SCALAR)(void *, const double , const double, double&);
typedef bool  (*RKF45_FUNCTION_VECTOR_COND)(void *, const CagmRKF45Vect&);
typedef bool  (*RKF45_FUNCTION_SCALAR_COND)(void *, const double);

class CagmRKF45
{
public:
    typedef enum {None = 0, EndByStep = 1, End = 2, EndByCond = 3, EndNoMove = 4, EndByLoop = 5, 
                  TooManyCalcs = 6, WrongErrBound = 7, TooLittleStep = 8, TooManyExits = 9, WrongCall = 10} Status;

protected:
    double m_absErr, m_relErr, m_absBoundAchieve;
    Status m_status;
    int m_n;
    double m_t, m_tOut, m_dt;
    bool m_bByStep;

    RKF45_FUNCTION_VECTOR m_funcv;
    CagmRKF45Vect m_vY;
    CagmRKF45Vect m_vYP;
    CagmRKF45Vect m_f1, m_f2, m_f3, m_f4, m_f5;
    RKF45_FUNCTION_VECTOR_COND m_fcondv;

    RKF45_FUNCTION_SCALAR m_funcs;
    double m_dY;
    double m_dYP;
    double m_df1, m_df2, m_df3, m_df4, m_df5;
    RKF45_FUNCTION_SCALAR_COND m_fconds;

    void *m_par;

    double m_h;
    double m_eps, m_u26;
    double m_estCond;
    double m_ae;

    double m_saveRE, m_saveAE;
    int m_nfe, m_kop;
    bool m_bInit;

    bool m_bVect;

    int m_nLoop;
    int m_pLoop;
    CagmRKF45Vect *m_vLoop;
    double m_loopCond;

// Construction
public:
    CagmRKF45(double absErr, double relErr, RKF45_FUNCTION_VECTOR func, int n, void *par,
        RKF45_FUNCTION_VECTOR_COND fcond = nullptr, double absBoundAchieve = 0, int nLoop = 0, double loopCond = 1e-4);
    CagmRKF45(double absErr, double relErr, RKF45_FUNCTION_SCALAR func, void *par, 
        RKF45_FUNCTION_SCALAR_COND fcond = nullptr, double absBoundAchieve = 0, int nLoop = 0, double loopCond = 1e-4);
    virtual ~CagmRKF45();

    CagmRKF45::Status calculate(double& t, CagmRKF45Vect& vY, double tOut, bool bByStep);
    CagmRKF45::Status GetStatus() { return m_status; };
    static bool isStatusCritical(CagmRKF45::Status status) { return status == TooManyCalcs || status == WrongErrBound || status == TooLittleStep || status == TooManyExits || status == WrongCall; }
    static bool isFinished(CagmRKF45::Status status) { return status == EndByCond || status == EndNoMove || status == EndByLoop; }
    void reinit(double absErr, double relErr, void *par);
    void reinit(void *par);

private:
    void reset(double absErr, double relErr);
    void setAbsErr(double absErr);
    void setRelErr(double relErr);
    CagmRKF45::Status integrator();
    uint32_t fehl(CagmRKF45Vect& s);
    uint32_t fehl(double& s);
    double estCond(uint32_t dwRes);
    double getEeEt(CagmRKF45::Status& status);
    bool checkLoop(CagmRKF45Vect& s);
};
